import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import ListPostUser from "./ListPostUser";
const UserDetails = () => {
  const navigate = useNavigate();
  const [singleUser, setSingleUser] = useState();
  const { id } = useParams();
  useEffect(() => {
    const User = localStorage.getItem("user");

    if (!User) {
      navigate("/login");
    }
  }, []);

  const singleUsers = () => {
    axios
      .get(
        `http://localhost:3100/api/user/${id}`,
        //{},
        {
          withCredentials: false,
        }
      )
      .then(function (response) {
        //setLoading(false);
        //setBlogData(response?.data?.data);
        setSingleUser(response.data.data);
        console.log(response?.data?.data);
      })
      .catch(function (error) {
        // handle error
        //setLoading(false);
        //   setMessage(error?.response?.data?.message);
        //   openSnackbar(error?.response?.data?.message);
        console.log(error);
      })
      .then(function () {
        // always executed
      });
  };
  useEffect(() => {
    singleUsers();
  }, []);
  return (
    <>
    {/* <div className="relative flex">
      <div className="max-w-3xl mb-10 rounded overflow-hidden flex flex-col mx-auto text-center">
        <div className="max-w-3xl mx-auto text-xl sm:text-4xl font-semibold inline-block hover:text-indigo-600 transition duration-500 ease-in-out inline-block mb-2">
         
        </div>

        <img className="w-full h-96 my-4 rounded-lg" src="https://www.w3schools.com/howto/img_avatar2.png" />
        <p className="text-gray-700 text-base leading-8 max-w-2xl mx-auto">
          Name: {singleUser?.FirstName} {singleUser?.LastName}
        </p>

        <hr />
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="mt-3 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
          <div className="">
            <p className="text-base leading-8 my-5"><span>Gmail: </span>{singleUser?.Email}</p>
            <p className="text-base leading-8 my-5"><span>Mô tả: </span></p>
            <p className="text-base leading-8 my-5"><span>Đến từ: </span></p>
          </div>
        </div>
      </div>
    </div> */}
    <div class="p-16">
      <div class="p-8 bg-white shadow mt-24">  
    <div class="grid grid-cols-1 md:grid-cols-3">   
     <div class="grid grid-cols-3 text-center order-last md:order-first mt-20 md:mt-0">  
         <div>   
                                        </div>    </div>    <div class="relative">   
                                           <div class="w-48 h-48 bg-indigo-100 mx-auto rounded-full shadow-2xl absolute inset-x-0 top-0 -mt-24 flex items-center justify-center text-indigo-500"> 
                                           <img className="rounded-full" src="https://www.w3schools.com/howto/img_avatar2.png" />
                                                </div> 
                                                   </div>  
                                                     <div class="space-x-8 flex justify-between mt-32 md:mt-0 md:justify-center">
                                                      <button  class="text-white py-2 px-4 uppercase rounded bg-blue-400 hover:bg-blue-500 shadow hover:shadow-lg font-medium transition transform hover:-translate-y-0.5">  Follow</button>    <button  class="text-white py-2 px-4 uppercase rounded bg-gray-700 hover:bg-gray-800 shadow hover:shadow-lg font-medium transition transform hover:-translate-y-0.5">  Add Friend</button>  
                                                        </div>  </div>  <div class="mt-20 text-center border-b pb-12">  

<p class="font-light text-gray-600 mt-3">{singleUser?.FirstName} {singleUser?.LastName}</p> 
<p class="mt-8 text-gray-500">{singleUser?.Email}</p>   
<p class="mt-2 text-gray-500">{singleUser?.phone}</p> 
  </div>
  <ListPostUser/>
  </div>
  </div>
     
      </>
  );
};

export default UserDetails;
