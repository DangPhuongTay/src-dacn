import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
const BlogDetail = () => {
  const navigate = useNavigate();
  const [singlePost, setSinglePost] = useState();
  const { id } = useParams();
  useEffect(() => {
    const User = localStorage.getItem("user");

    if (!User) {
      navigate("/login");
    }
  }, []);

  const singleBlog = () => {
    axios
      .get(
        `http://localhost:3100/api/allpost/${id}`,
        //{},
        {
          withCredentials: false,
        }
      )
      .then(function (response) {
        //setLoading(false);
        //setBlogData(response?.data?.data);
        setSinglePost(response.data.data);
        console.log(response?.data?.data);
      })
      .catch(function (error) {
        // handle error
        //setLoading(false);
        //   setMessage(error?.response?.data?.message);
        //   openSnackbar(error?.response?.data?.message);
        console.log(error);
      })
      .then(function () {
        // always executed
      });
  };
  useEffect(() => {
    singleBlog();
  }, []);
  return (
    <div className="relative">
      <div className="max-w-3xl mb-10 rounded overflow-hidden flex flex-col mx-auto " >
      
        <div className="max-w-3xl  text-xl sm:text-4xl font-semibold inline-block hover:text-indigo-600 transition duration-500 ease-in-out inline-block mb-2">
        <h3 className="my-10">
          {singlePost?.Title} 
        </h3>
        <hr />
        <p className="text-gray-700 text-base leading-8 max-w-2xl">
         {singlePost?.Topic} 
        </p>
        
        <p className="text-gray-700 text-base leading-8 max-w-2xl ">
        Creat By: {singlePost?.user?.FirstName} {singlePost?.user?.LastName}
        </p>
        <img className="w-full h-96 my-4" src={singlePost?.Image} />
      
        </div>
      
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="mt-3 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
          <div className="">
            <p className="text-base leading-8 my-5">{singlePost?.Desc1}</p>
            <p className="text-base leading-8 my-5">{singlePost?.Desc2}</p>
            <div className="max-w-3xl mx-auto">
        <div className="mt-3 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
          <div className="">
            <p className="text-base leading-8 my-5"><span className="font-medium">Thời gian hoạt động: </span>{singlePost?.Time}</p>
            <p className="text-base leading-8 my-5"><span className="font-medium">Địa chỉ: </span>{singlePost?.Address}</p>
            <p className="text-base leading-8 my-5"><span className="font-medium">Chi phí tham khảo: </span>{singlePost?.Price}</p>
          </div>
        </div>
      </div>
            <p className="text-base leading-8 my-5">{singlePost?.Desc3}</p>
          </div>
        </div>
        <hr />
      </div>

     
      
    </div>
  );
};

export default BlogDetail;
